/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package collaudarettaelsayed;
import libreria.Fraction;

/**
 *
 * @author moham
 */
public class CollaudaRettaElsayed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Fraction a,b,c,d,e;
       a = b = c=d=e= null;
       a = new Fraction (2,5);
       b = new Fraction (5,2);
       c = new Fraction (5,5);
       d = new Fraction (3,5);
       e = new Fraction (0,2);
       
    }
    
}
