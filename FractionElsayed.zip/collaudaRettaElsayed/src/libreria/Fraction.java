/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria;

/**
 *
 * @author moham
 */
public class Fraction {

    private Integer numerator;

    private Integer denominator;

    public Fraction(Integer numerator, Integer denominator) {
        if(numerator == null || denominator == null ){
            throw new IllegalArgumentException("Numerator e denominator non possono essere null");
        }
        if (denominator == null ){
            throw new IllegalArgumentException("Denominator non possono essere null");
        }
        this.numerator = numerator;
        this.denominator = denominator;
    }

    /**
     * Get the value of denominator
     *
     * @return the value of denominator
     */
    public Integer getDenominator() {
        return denominator;
    }

    /**
     * Get the value of numerator
     *
     * @return the value of numerator
     */
    public Integer getNumerator() {
        return numerator;
    }

    @Override
    public String toString() {
        return "Fraction{" + "numerator=" + numerator + ", denominator=" + denominator + '}';
    }

    
    
}
