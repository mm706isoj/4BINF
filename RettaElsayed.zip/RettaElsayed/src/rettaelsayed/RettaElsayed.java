/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Rettaelsayed;
import libreria.Retta;

/**
 *
 * @author moham
 */
public class RettaElsayed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Retta a, b, c, d, e;
        a = b = c = d = e = null;
        a = new Retta(0.0, 1.0);
        b = new Retta(1.0, 0.0);
        c = new Retta(1.0, 3.0);
        d = new Retta(3.0, 1.0);
        e = new Retta(2.0, 0.0);

        Retta f, g, h, i, j;
        f = g = h = i = j = null;


        try {
            f = new Retta(1.0, 2.0, 1.0);
            g = new Retta(2.0, 1.0, 3.0);
            h = new Retta(1.0, 3.0, 2.0);
            i = new Retta(0.0, 3.0, 0.0);
            j = new Retta(2.0, 0.0, 3.0);

        } catch (IllegalArgumentException e1) {
            System.out.println("Eccezione" + e);
        }

        System.out.println(f);
        System.out.println(g);
        System.out.println(h);
        System.out.println(i);
    }
}
