package libreria;

/**
 *
 * @author moham
 */
public class Retta {
    
    private double m;
    private double q;

    public Retta(Double m, Double q) {
        if (m == null || q == null) {
            throw new IllegalArgumentException("m e q non possono essere null");
        }
        this.m = m;
        this.q = q;
    }

    public Retta(Double a, Double b, Double c) {
        if (a == null || b == null || c == null) {
            throw new IllegalArgumentException("i parametri a, b, c non possono essere null");
        }
        if (b == 0) {
            throw new IllegalArgumentException("Denominator b non può essere zero");
        }
        this.m = -a / b;
        this.q = -c / b;
    }

    /**
     * Get the value of q
     *
     * @return the value of q
     */
    public double getQ() {
        return q;
    }

    /**
     * Get the value of m
     *
     * @return the value of m
     */
    public double getM() {
        return m;
    }

    @Override
    public String toString() {
        return "Retta{" + "m=" + m + ", q=" + q + '}';
    }
}

